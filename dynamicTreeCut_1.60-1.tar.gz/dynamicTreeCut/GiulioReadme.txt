A small mod has been made in treeCut.R, which should prevent some crashes.

            # small mod by Giulio Costantini
            if(!is.null(dim(UnassdToClustDist)))
            {
              nearest = apply(UnassdToClustDist, 2, which.min);
              nearestDist = apply(UnassdToClustDist, 2, min);
            } else {
              nearest = which.min(UnassdToClustDist);
              nearestDist = min(UnassdToClustDist);;
            }
            # end mod
			
			